<?php session_start(); include 'db.php'; ?>
<!DOCTYPE html><html><body>
<form method='post' action='save_school.php'>
Nombre:<input name='nombre'><br>
Clave:<input name='clave'><br>
Nivel:<input name='nivel'><br>
Dirección:<input name='direccion'><br>
<button>Guardar</button>
</form>
</body></html>