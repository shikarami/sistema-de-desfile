<?php session_start(); ?>
<!DOCTYPE html><html><body>
<form method='post' action='validar.php'>
Usuario:<input name='usuario'><br>
Contraseña:<input type='password' name='clave'><br>
<button>Entrar</button>
</form>
</body></html>