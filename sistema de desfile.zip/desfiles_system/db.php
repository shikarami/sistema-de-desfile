<?php
$conn = new mysqli("localhost", "root", "", "desfiles");
if ($conn->connect_error) { die("Error DB: " . $conn->connect_error); }
?>