<!DOCTYPE html><html><body>
<h2>Mapa</h2>
<div id='map' style='height:500px;width:100%;'></div>
<script>
function initMap(){
 const map=new google.maps.Map(document.getElementById('map'),{zoom:12,center:{lat:18.2,lng:-96.0}});
}
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&callback=initMap" async></script>
</body></html>