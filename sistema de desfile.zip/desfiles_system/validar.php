<?php
session_start();
include 'db.php';
$u=$_POST['usuario']; $c=$_POST['clave'];
$q=$conn->query("SELECT * FROM usuarios WHERE usuario='$u' AND clave='$c'");
if($q->num_rows>0){ $_SESSION['user']=$u; header("Location: panel.php");}
else{ echo "Error"; }
?>