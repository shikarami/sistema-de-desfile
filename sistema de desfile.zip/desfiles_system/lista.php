<?php include 'db.php'; $q=$conn->query("SELECT * FROM escuelas"); ?>
<!DOCTYPE html><html><body>
<h2>Escuelas Registradas</h2>
<?php while($r=$q->fetch_assoc()): ?>
<div><?php echo $r['nombre'].' - '.$r['clave'].' - '.$r['nivel'].' - '.$r['direccion']; ?></div>
<?php endwhile; ?>
</body></html>