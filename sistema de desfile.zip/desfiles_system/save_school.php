<?php
include 'db.php';
$n=$_POST['nombre']; $c=$_POST['clave']; $ni=$_POST['nivel']; $d=$_POST['direccion'];
$conn->query("INSERT INTO escuelas(nombre, clave, nivel, direccion) VALUES('$n','$c','$ni','$d')");
header("Location: registrar.php");
?>