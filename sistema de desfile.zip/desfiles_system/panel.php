<?php session_start(); if(!isset($_SESSION['user'])){ header("Location: login.php"); exit; } ?>
<!DOCTYPE html><html><body>
<h2>Panel Principal</h2>
<a href='registrar.php'>Registrar Escuela</a><br>
<a href='lista.php'>Lista</a><br>
<a href='mapa.php'>Mapa</a><br>
</body></html>